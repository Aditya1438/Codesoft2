# CODSOFT
Some Projects which are developed during the Internship phase.

*Deployment link* (Landing page)- https://onlineveggeshop.netlify.app/ <br>
*Deployment link* (Portfolio)- https://harshtiwari.netlify.app/
